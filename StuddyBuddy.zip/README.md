# StuddyBuddy

Open index.html in a browser. For local HTTP testing run python3 -m http.server 8000 in this directory.

## GitHub Pages
Copy index.html, style.css, app.js and .nojekyll into the root of a GitHub repository and commit to main. In Settings → Pages choose Deploy from a branch, main, /(root), and Save. GitHub displays the site URL when the deployment completes.

## Try the full flow
Open Syllabus parser, choose Try sample text, extract dates and correct any entries before saving. Calendar exports all imported events to one ICS file. If you have no imports it exports the clearly labeled sample calendar.

Study groups matches the selected course against a simulated course roster. Enter your usual free days and times, choose a goal, and create a group. Save questions, annotations, or notes in its workspace. Export a text copy for classmates.

## Frontend scope
Dates, preferences, groups and materials persist in browser local storage. There are no accounts or cross-device synchronization. PDF import loads PDF.js from jsDelivr and reads selectable text locally. Scanned pages require pasted text. The line parser supports ISO dates, US numeric dates and English month-first dates, with optional hours. It assumes the current year for undated years. Review the extracted rows before adding them. For CSV, use one dated item per line, e.g. 2026-11-20,Midterm,10:00 AM. Timed calendar entries use local floating time. Demo roster members are fictional.
