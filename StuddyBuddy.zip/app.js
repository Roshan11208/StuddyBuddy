'use strict';
const $ = s => document.querySelector(s);
const esc = value => String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad = v=>String(v).padStart(2,'0');
const iso = d=>[d.getFullYear(),pad(d.getMonth()+1),pad(d.getDate())].join('-');
const dateOf = s=>new Date(s+'T12:00:00');
const today = new Date();
const after = n=>new Date(today.getFullYear(),today.getMonth(),today.getDate()+n);
const uid = ()=>crypto.randomUUID();
const courses=['Calculus II','Physics I','Linear Algebra','Organic Chemistry'];
const seedEvents=['Integration techniques worksheet','Newton’s laws problem set','Chapter 5 reading'].map((title,i)=>({id:uid(),title,course:courses[i],date:iso(after(i+1)),time:'',kind:['Assignment','Assignment','Reading'][i],demo:true}));
const key='studdybuddy.workspace.v1';
let state=JSON.parse(localStorage.getItem(key)||'null')||{events:seedEvents,groups:[],profile:null};
const save=()=>localStorage.setItem(key,JSON.stringify(state));
let timer;
function notify(msg){$('#toast').textContent=msg;clearTimeout(timer);timer=setTimeout(()=>$('#toast').textContent='',4500)}
const pages=['Overview','Syllabus parser','Calendar','Study groups','Workspace'];
const icons=['▦','▤','▦','♧','▥'];
let month=new Date(today.getFullYear(),today.getMonth(),1),selected='',draft=[],match=null,activeGroup='';
const goto=page=>{location.hash=encodeURIComponent(page);render()};
function render(){
 const page=pages.find(p=>'#'+encodeURIComponent(p)===location.hash)||'Overview';
 $('#crumb').textContent=page;$('#today').textContent=today.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
 $('#nav').innerHTML=pages.map((p,i)=>'<button class="'+(p===page?'active':'')+'" data-page="'+p+'"><span class="ico">'+icons[i]+'</span>'+p+'</button>').join('');
 const view=$('#view');view.innerHTML=({'Overview':overview,'Syllabus parser':parser,'Calendar':calendar,'Study groups':groups,'Workspace':workspace}[page])();
 if(page==='Overview')drawBooks();
 if(page==='Syllabus parser')bindParser();
 if(page==='Study groups')bindMatch();
 if(page==='Workspace')bindWorkspace();
}
function list(events){return events.length?events.slice().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).map(e=>{const d=dateOf(e.date);return '<div class="row"><div class="date"><small>'+d.toLocaleString('en',{month:'short'}).toUpperCase()+'</small>'+d.getDate()+'</div><div><strong>'+esc(e.title)+'</strong><small>'+esc(e.course)+' · '+esc(e.time||'All day')+(e.demo?' · Sample':'')+'</small></div><span class="pill '+e.kind+'">'+e.kind+'</span></div>'}).join(''):'<p class="muted">No events for this period.</p>'}
function overview(){return '<section class="hero"><div class="eyebrow">✳ &nbsp; STUDENT DASHBOARD</div><h1>Your study desk.</h1><p>Turn syllabi into a calendar and find classmates who can study when you can.</p><canvas id="art" aria-hidden="true"></canvas></section><div class="section"><h2>Study tools</h2></div><div class="grid"><article class="card"><div class="stamp">▤</div><h3>Syllabus parser</h3><p>Pull assignments, readings, and exams into one course calendar.</p><button class="action" data-page="Syllabus parser">Upload syllabus &nbsp; ↗</button></article><article class="card"><div class="stamp peach">♧</div><h3>Study matchmaker</h3><p>Build a small study group around your course, goals, and free time.</p><button class="secondary" data-page="Study groups">Find a group &nbsp; →</button></article></div><div class="section"><h2>Upcoming deadlines</h2><button class="link" data-page="Calendar">View calendar →</button></div><div class="panel">'+list(state.events.filter(e=>e.date>=iso(today)).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,4))+'</div>'}
function drawBooks(){
 const c=$('#art'),ctx=c.getContext('2d');c.width=640;c.height=460;ctx.scale(2,2);ctx.lineJoin='round';ctx.lineWidth=2;
 function poly(pts,fill){ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();ctx.strokeStyle='#29372e';ctx.stroke()}
 function book(x,y,w,h,color){ctx.save();ctx.translate(x,y);poly([[0,0],[w,-19],[w+54,8],[54,29]],color);poly([[0,0],[54,29],[54,29+h],[0,h]],color);poly([[54,29],[w+54,8],[w+54,8+h],[54,29+h]],'#fffbed');ctx.strokeStyle='#a5a093';ctx.lineWidth=1;for(let k=3;k<h;k+=3){ctx.beginPath();ctx.moveTo(57,29+k);ctx.lineTo(w+52,8+k);ctx.stroke()}ctx.restore()}
 book(50,151,147,16,'#b3b8ed');book(39,127,150,13,'#efab78');book(57,103,139,17,'#8d9ddf');book(45,80,139,13,'#b8cf90');
 ctx.save();ctx.translate(203,36);ctx.rotate(.48);poly([[0,0],[9,0],[9,84],[4.5,98],[0,84]],'#ffd276');poly([[0,84],[9,84],[4.5,98]],'#ffe7c6');poly([[2.5,92],[6.5,92],[4.5,98]],'#30352c');ctx.restore();ctx.font='italic 18px Georgia';ctx.fillStyle='#536944';ctx.fillText('∑',33,58);ctx.fillText('x²',246,154);ctx.fillText('✧',248,61)
}
function heading(title,desc){return '<h1>'+title+'</h1><p class="sub">'+desc+'</p>'}
function options(arr,sel){return arr.map(x=>'<option '+(x===sel?'selected':'')+'>'+esc(x)+'</option>').join('')}
function parser(){return heading('Syllabus parser','Upload a syllabus, review the extracted dates, and add them to your calendar.')+'<section class="panel form"><label>Course<input id="course" placeholder="e.g. Calculus II" value="'+esc(state.profile?.course||'Calculus II')+'"></label><div class="drop" id="drop"><strong>Drop your syllabi here</strong><br><small>PDF with selectable text, TXT, or dated CSV rows</small><input aria-label="Choose syllabus files" type="file" multiple accept=".pdf,.txt,.csv" id="files"></div><label>Or paste your syllabus text<textarea id="raw" placeholder="November 20, '+today.getFullYear()+' — Midterm exam at 10:30 AM"></textarea></label><div class="bar"><button class="action" id="parse">Extract dates</button><button class="link" id="sample">Try sample text</button></div><div id="status" role="status"></div></section><div id="review"></div>'}
function extract(raw,course){
 const monthNames='Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?';
 const pattern=new RegExp('\\b(?:\\d{4}-\\d{2}-\\d{2}|\\d{1,2}/\\d{1,2}(?:/\\d{4})?|(?:'+monthNames+')\\.?\\s+\\d{1,2}(?:st|nd|rd|th)?(?:,?\\s+\\d{4})?)\\b','i');
 const result=[];
 for(const line of raw.split(/\r?\n/)){const hit=line.match(pattern);if(!hit)continue;let str=hit[0],y=today.getFullYear(),m,d;
 if(str.includes('-'))[y,m,d]=str.split('-').map(Number);else if(str.includes('/')){const a=str.split('/').map(Number);[m,d]=a;y=a[2]||y}else{const a=str.match(/[a-z]+|\d+/ig);m=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'].indexOf(a[0].slice(0,3).toLowerCase())+1;d=+a[1];y=+(str.match(/\d{4}$/)||[y])[0]}
 const date=new Date(y,m-1,d);if(date.getMonth()!==m-1||date.getDate()!==d)continue;
 let title=line.replace(str,' ');const t=title.match(/\b(?:([01]?\d|2[0-3]):([0-5]\d)\s*(am|pm)?|(1[0-2]|[1-9])\s*(am|pm))\b/i);let time='';
 if(t){let h=+(t[1]||t[4]);const mer=t[3]||t[5];if(mer)h=h%12+(/pm/i.test(mer)?12:0);time=pad(h)+':'+(t[2]||'00');title=title.replace(t[0],'')}
 title=title.replace(/\bat\s*$/i,'').replace(/^[\s,;:–—-]+|[\s,;:–—-]+$/g,'').trim();
 result.push({id:uid(),date:iso(date),time,title:title||'Course event',course,kind:/exam|midterm|final|quiz/i.test(title)?'Exam':/read|chapter/i.test(title)?'Reading':'Assignment'})
 }return result
}
async function fileText(file){
 if(!/\.pdf$/i.test(file.name))return file.text();
 const pdf=await import('https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.min.mjs');
 pdf.GlobalWorkerOptions.workerSrc='https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.worker.min.mjs';
 const doc=await pdf.getDocument({data:await file.arrayBuffer(),isEvalSupported:false}).promise;
 let out='';try{for(let i=1;i<=doc.numPages;i++){const page=await doc.getPage(i),content=await page.getTextContent();out+=content.items.map(item=>item.str+(item.hasEOL?'\n':' ')).join('')+'\n'}}finally{await doc.destroy()}return out
}
function bindParser(){
 let files=[];const drop=$('#drop');$('#files').onchange=e=>{files=[...e.target.files]};
 drop.ondragover=e=>e.preventDefault();drop.ondrop=e=>{e.preventDefault();files=[...e.dataTransfer.files];$('#status').textContent=files.map(f=>f.name).join(', ')};
 $('#sample').onclick=()=>{$('#raw').value=[1,3,6].map((n,i)=>iso(after(n))+' — '+['Problem set 4','Read chapter 8','Midterm exam at 2:30 PM'][i]).join('\n')};
 $('#parse').onclick=async()=>{const button=$('#parse'),status=$('#status'),course=$('#course').value.trim();if(!course){status.textContent='Enter a course name first.';return}button.disabled=true;status.textContent='Reading syllabus…';let parsed=extract($('#raw').value,course),messages=[];
 for(const f of files){try{const rows=extract(await fileText(f),course);parsed.push(...rows);if(!rows.length)messages.push(f.name+' has no readable dates. Paste text for scanned pages.')}catch{messages.push('Could not read '+f.name+'. Paste its text below.')}}draft=parsed;status.textContent=[parsed.length+' dates found.',...messages].join(' ');button.disabled=false;if($('#review'))review()};review()
}
function review(){const box=$('#review');if(!draft.length){box.innerHTML='';return}box.innerHTML='<section class="panel"><h2>Review dates</h2><p class="muted">Check titles, dates, and local times before saving.</p><form id="events">'+draft.map((e,i)=>'<div class="edit"><input required aria-label="Event title" data-field="title" value="'+esc(e.title)+'"><input required type="date" aria-label="Event date" data-field="date" value="'+e.date+'"><input type="time" aria-label="Event time" data-field="time" value="'+e.time+'"><button type="button" aria-label="Remove event" data-remove="'+i+'">×</button></div>').join('')+'<button class="action">Add to calendar</button></form></section>';
 $('#events').oninput=e=>{if(e.target.dataset.field)draft[[...e.target.parentElement.parentElement.children].indexOf(e.target.parentElement)][e.target.dataset.field]=e.target.value};
 box.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{draft.splice(+b.dataset.remove,1);review()});
 $('#events').onsubmit=e=>{e.preventDefault();for(const item of draft)if(!state.events.some(x=>!x.demo&&['title','course','date','time'].every(k=>x[k]===item[k])))state.events.push(item);month=dateOf(draft[0].date);month.setDate(1);selected='';save();draft=[];goto('Calendar');notify('Calendar updated')}
}
function calendar(){
 const prefix=iso(month).slice(0,7),items=state.events.filter(e=>e.date.startsWith(prefix));
 const cells=Array(month.getDay()).fill('<span></span>');
 for(let n=1;n<=new Date(month.getFullYear(),month.getMonth()+1,0).getDate();n++){const day=prefix+'-'+pad(n);cells.push('<button data-date="'+day+'" class="day '+(items.some(e=>e.date===day)?'has ':'')+(selected===day?'selected':'')+'">'+n+'</button>')}
 return heading('Course calendar','Your course deadlines and exams in one place.')+'<div class="panel"><div class="section"><h2>'+month.toLocaleDateString('en',{month:'long',year:'numeric'})+'</h2><div class="bar"><button aria-label="Previous month" data-month="-1">←</button><button aria-label="Next month" data-month="1">→</button></div></div><div class="month">'+['Su','Mo','Tu','We','Th','Fr','Sa'].map(x=>'<small>'+x+'</small>').join('')+cells.join('')+'</div><div class="bar"><button class="action" data-page="Syllabus parser">Add syllabus</button><button class="secondary" id="export">Download .ics</button></div></div><div class="section"><h2>'+(selected?esc(selected):'This month')+'</h2>'+(selected?'<button class="link" data-date="">Show month</button>':'')+'</div><div class="panel">'+list(items.filter(e=>!selected||e.date===selected))+'</div>'
}
function download(name,text,type){const url=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1200)}
function ical(events){
 const safe=s=>String(s).replace(/\\/g,'\\\\').replace(/\r?\n/g,'\\n').replace(/([,;])/g,'\\$1');
 const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//StuddyBuddy//Study calendar//EN','CALSCALE:GREGORIAN'];
 for(const e of events){const date=e.date.replaceAll('-',''),start=e.time?'DTSTART:'+date+'T'+e.time.replace(':','')+'00':'DTSTART;VALUE=DATE:'+date;lines.push('BEGIN:VEVENT','UID:'+e.id+'@studdybuddy','DTSTAMP:'+new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,''),start,'SUMMARY:'+safe(e.title),'DESCRIPTION:'+safe(e.course),'END:VEVENT')}
 lines.push('END:VCALENDAR');return lines.map(l=>{let out='',bytes=0;for(const ch of l){const size=new TextEncoder().encode(ch).length;if(bytes+size>75){out+='\r\n ';bytes=1}out+=ch;bytes+=size}return out}).join('\r\n')+'\r\n'
}
const days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],goals=['Practice problems','Exam preparation','Concept review'];
class StudyMatcher{
 constructor(course){this.students=['Maya Chen','Noah Brooks','Avery Patel','Lena Ortiz','Sam Rivera','Kai Morgan','Zoe Park','Eli James'].map((name,i)=>({name,course,goal:goals[i%3],days:[0,1,2,3,4,5,6].filter(d=>(i+d)%4!==0),start:8+(i%4)*2,end:17+(i%4)}))}
 find(profile){let best=null;
 for(const day of profile.days){for(let start=profile.start;start+1<=profile.end;start+=0.5){
 const available=this.students.filter(s=>s.days.includes(day)&&s.start<=start&&s.end>=start+1).sort((a,b)=>Number(b.goal===profile.goal)-Number(a.goal===profile.goal)).slice(0,3);
 if(available.length<2)continue;const score=available.filter(s=>s.goal===profile.goal).length*10+available.length;
 if(!best||score>best.score)best={id:uid(),course:profile.course,goal:profile.goal,day,start,score,members:available.map(s=>s.name),notes:[]}
 }}return best}
}
const clock=h=>pad(Math.floor(h))+':'+pad(Math.round((h%1)*60));
function groups(){const p=state.profile||{course:courses[0],goal:goals[0],days:[0,2],start:14,end:17};
 return heading('Study matchmaker','Find a group of 3–4 with a common course and a full hour together.')+'<div class="grid"><form id="matchform" class="panel form"><h2>Your study preferences</h2><label>Course<select name="course">'+options([...new Set([...courses,...state.events.map(e=>e.course)])],p.course)+'</select></label><label>Study goal<select name="goal">'+options(goals,p.goal)+'</select></label><div><strong>Free days</strong><div class="slots">'+days.map((d,i)=>'<label><input type="checkbox" name="days" value="'+i+'" '+(p.days.includes(i)?'checked':'')+'>'+d+'</label>').join('')+'</div></div><div class="grid"><label>Free from<input type="time" name="start" required value="'+clock(p.start)+'"></label><label>Until<input type="time" name="end" required value="'+clock(p.end)+'"></label></div><button class="action">Find compatible classmates</button></form><div class="panel"><div class="stamp peach">♧</div><h3>Your group match</h3><p class="muted">Try matching with sample student profiles. Your preferences and groups stay in this browser.</p><div id="result" role="status"></div></div></div>'
}
function bindMatch(){const show=()=>{if(!match)return;$('#result').innerHTML='<h2>'+esc(match.course)+'</h2><p>'+days[match.day]+' · '+clock(match.start)+'–'+clock(match.start+1)+'</p><p>'+esc(['You',...match.members].join(' · '))+'</p><button id="join" class="action">Create group workspace</button>';$('#join').onclick=()=>{const existing=state.groups.find(g=>g.course===match.course&&g.day===match.day&&g.start===match.start&&g.members.join()===match.members.join());if(!existing)state.groups.push(match);activeGroup=(existing||match).id;save();match=null;goto('Workspace')}};
 $('#matchform').oninput=()=>{match=null;$('#result').textContent=''};
 $('#matchform').onsubmit=e=>{e.preventDefault();const data=new FormData(e.target),hours=str=>{let [h,m]=str.split(':').map(Number);return h+m/60};
 const profile={course:data.get('course'),goal:data.get('goal'),days:data.getAll('days').map(Number),start:hours(data.get('start')),end:hours(data.get('end'))};
 if(!profile.days.length||profile.end-profile.start<1){$('#result').textContent='Choose a free day and a window of at least one hour.';return}state.profile=profile;save();match=new StudyMatcher(profile.course).find(profile);if(match)show();else $('#result').textContent='No shared hour found. Try another day or a wider time window.'};show()
}
function workspace(){const g=state.groups.find(g=>g.id===activeGroup)||state.groups[0];if(!g)return heading('Group workspace','Keep notes, textbook annotations, and review questions together.')+'<div class="panel"><h2>Find your first group</h2><p class="muted">Choose a course and your free hours to create a workspace.</p><button class="action" data-page="Study groups">Find a group →</button></div>';
 activeGroup=g.id;return heading('Group workspace','Organize materials for your next study session.')+'<div class="panel form"><label>Study group<select id="group">'+state.groups.map(x=>'<option value="'+x.id+'" '+(x.id===g.id?'selected':'')+'>'+esc(x.course)+' · '+days[x.day]+' '+clock(x.start)+'</option>').join('')+'</select></label><div><strong>'+esc(['You',...g.members].join(' · '))+'</strong><br>'+esc(g.goal)+' · '+days[g.day]+' '+clock(g.start)+'–'+clock(g.start+1)+'</div></div><div class="grid"><form id="newnote" class="panel form"><h2>Add study material</h2><label>Type<select name="type">'+options(['Note','Textbook annotation','Review question'])+'</select></label><label>Title or textbook page<input name="title" required maxlength="160"></label><label>Content<textarea name="body" required></textarea></label><button class="action">Save material</button></form><div class="panel"><h2>Study materials</h2><p class="muted">Saved on this device. Export a copy to share with classmates.</p>'+g.notes.map(n=>'<article class="row"><div><small>'+esc(n.type)+'</small><strong>'+esc(n.title)+'</strong><div class="note">'+esc(n.body)+'</div></div></article>').join('')+(g.notes.length?'<button class="secondary" id="share">Export materials</button>':'<p>No materials yet.</p>')+'</div></div>'
}
function bindWorkspace(){if(!$('#group'))return;const g=state.groups.find(x=>x.id===activeGroup);$('#group').onchange=e=>{activeGroup=e.target.value;render()};$('#newnote').onsubmit=e=>{e.preventDefault();g.notes.unshift(Object.fromEntries(new FormData(e.target)));save();render()};if($('#share'))$('#share').onclick=()=>download('study-materials.txt',[g.course,...g.notes.map(n=>n.type+' — '+n.title+'\n'+n.body)].join('\n\n'),'text/plain')}
document.onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.page)goto(b.dataset.page);if(b.hasAttribute('data-month')){month.setMonth(month.getMonth()+Number(b.dataset.month));selected='';render()}if(b.hasAttribute('data-date')){selected=b.dataset.date;render()}if(b.id==='export'){const real=state.events.filter(x=>!x.demo);download(real.length?'studdybuddy-calendar.ics':'studdybuddy-sample-calendar.ics',ical(real.length?real:state.events),'text/calendar');notify(real.length?'Course calendar downloaded':'Sample calendar downloaded')}};
window.addEventListener('hashchange',render);save();render();
